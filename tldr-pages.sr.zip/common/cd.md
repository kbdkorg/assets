# cd

> Menja trenutnu radnu površinu.
> Više informacija na: <https://manned.org/cd>.

- Ulazi u dati direktoriju:

`cd {{putanja/do/direktorijuma}}`

- Ulazi u početni direktorjum trenutnog korisnika:

`cd`

- Ulazi u roditelja trenutnog direktorijuma:

`cd ..`

- Ulazi u prethodno izabrani direktorijum:

`cd -`
