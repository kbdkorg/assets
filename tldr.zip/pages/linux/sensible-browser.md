# sensible-browser

> Open the default browser.
> More information: <https://manned.org/sensible-browser>.

- Open a new window of the default browser:

`sensible-browser`

- Open a URL in the default browser:

`sensible-browser {{url}}`
