# nmcli monitor

> Monitor changes to the NetworkManager connection status.
> This subcommand can also be called with `nmcli m`.
> More information: <https://networkmanager.dev/docs/api/latest/nmcli.html>.

- Start monitoring NetworkManager changes:

`nmcli monitor`
