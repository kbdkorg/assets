# sensors

> Report sensors information.
> More information: <https://manned.org/sensors>.

- Show the current readings of all sensor chips:

`sensors`

- Show temperatures in degrees Fahrenheit:

`sensors --fahrenheit`
