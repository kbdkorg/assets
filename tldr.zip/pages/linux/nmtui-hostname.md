# nmtui-hostname

> This command is an alias of `nmtui hostname`.

- View documentation for the original command:

`tldr nmtui`
