# mkdir

> Kreira direktorijum.
> Više informacija na: <https://www.gnu.org/software/coreutils/mkdir>.

- Kreira direktorijum u trenutnom direktorijumu ili zadatoj lokaciji:

`mkdir {{direktorijum}}`

- Kreira više direktorijuma u trenutnom direktorijumu:

`mkdir {{direktorijum_1 direktorijum_2 ...}}`

- Kreira direktorijum koristeći rekurziju:

`mkdir -p {{putanja/do/direktorijuma}}`
