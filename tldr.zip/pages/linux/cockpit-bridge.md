# cockpit-bridge

> Relay messages and commands between the front end and server in the cockpit suite.
> More information: <https://cockpit-project.org/guide/latest/cockpit-bridge.1.html>.

- List all cockpit packages:

`cockpit-bridge --packages`

- Display help:

`cockpit-bridge --help`
