# battop

> An interactive viewer for the batteries installed in your notebook.
> More information: <https://github.com/svartalf/rust-battop>.

- Display battery information:

`battop`

- Change battery information measurement [u]nit (default: human):

`battop -u {{human|si}}`
