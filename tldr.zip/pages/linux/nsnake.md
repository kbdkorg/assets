# nsnake

> Snake game in the terminal.
> More information: <https://github.com/alexdantas/nsnake/>.

- Start a snake game:

`nsnake`

- Navigate the snake:

`{{Up|Down|Left|Right}} arrow key`

- Pause/unpause the game:

`p`

- Quit the game:

`q`

- Display help during the game:

`h`
