# pkgctl release

> Release step to commit, tag and upload build artifacts.
> More information: <https://man.archlinux.org/man/pkgctl-release.1>.

- Release a build artifact:

`pkgctl release --repo {{repository}} --message {{commit_message}}`
