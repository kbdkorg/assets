# link

> Kreira link između novog i zadatog fajla.
> Više informacija na: <https://www.gnu.org/software/coreutils/link>.

- Kreira link između novog i zadatog fajla:

`link {{putanja/do/postojećeg_fajla}} {{putanja/do/novog_fajla}}`
