# ip route list

> This command is an alias of `ip route show`.

- View documentation for the original command:

`tldr ip-route-show`
